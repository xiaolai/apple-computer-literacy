//
//  Companion+CoreDataClass.h
//  
//
//  Created by Kindle Build User on 10/7/21.
//
//  This file was automatically generated and should not be edited.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Audiobook;

NS_ASSUME_NONNULL_BEGIN

@interface Companion : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "Companion+CoreDataProperties.h"
