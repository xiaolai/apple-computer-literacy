//
//  Companion+CoreDataProperties.h
//  
//
//  Created by Kindle Build User on 10/7/21.
//
//  This file was automatically generated and should not be edited.
//

#import "Companion+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface Companion (CoreDataProperties)

+ (NSFetchRequest<Companion *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *audioACR;
@property (nullable, nonatomic, copy) NSString *audioAmazonASIN;
@property (nullable, nonatomic, copy) NSString *audioASIN;
@property (nullable, nonatomic, copy) NSString *audioFormat;
@property (nonatomic) BOOL audioOwned;
@property (nonatomic) int64_t audioVersion;
@property (nullable, nonatomic, copy) NSString *ebookACR;
@property (nullable, nonatomic, copy) NSString *ebookAsin;
@property (nullable, nonatomic, copy) NSString *ebookFormat;
@property (nonatomic) BOOL ebookOwned;
@property (nullable, nonatomic, copy) NSString *ebookVersion;
@property (nonatomic) BOOL isPrimaryCompanion;
@property (nullable, nonatomic, copy) NSString *syncfileACR;
@property (nullable, nonatomic, copy) NSString *syncfileDownloadStatus;
@property (nullable, nonatomic, copy) NSString *syncfilePath;
@property (nullable, nonatomic, retain) Audiobook *audiobook;

@end

NS_ASSUME_NONNULL_END
