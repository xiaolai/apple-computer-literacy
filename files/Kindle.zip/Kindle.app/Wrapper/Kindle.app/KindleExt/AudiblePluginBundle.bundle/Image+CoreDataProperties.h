//
//  Image+CoreDataProperties.h
//  
//
//  Created by Kindle Build User on 10/7/21.
//
//  This file was automatically generated and should not be edited.
//

#import "Image+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface Image (CoreDataProperties)

+ (NSFetchRequest<Image *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *filepath;
@property (nullable, nonatomic, copy) NSString *type;
@property (nullable, nonatomic, copy) NSString *uniqueID;
@property (nullable, nonatomic, retain) Audiobook *audio;

@end

NS_ASSUME_NONNULL_END
