//
//  ImmersionReading+CoreDataModel.h
//  
//
//  Created by Kindle Build User on 10/7/21.
//
//  This file was automatically generated and should not be edited.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

#import "Audiobook+CoreDataClass.h"
#import "Companion+CoreDataClass.h"
#import "Image+CoreDataClass.h"




