//
//  Audiobook+CoreDataProperties.h
//  
//
//  Created by Kindle Build User on 10/7/21.
//
//  This file was automatically generated and should not be edited.
//

#import "Audiobook+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface Audiobook (CoreDataProperties)

+ (NSFetchRequest<Audiobook *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *amazonAsin;
@property (nullable, nonatomic, copy) NSString *asin;
@property (nullable, nonatomic, retain) NSData *authors;
@property (nullable, nonatomic, copy) NSString *codecString;
@property (nullable, nonatomic, copy) NSString *contentDeliveryType;
@property (nullable, nonatomic, copy) NSString *contentType;
@property (nullable, nonatomic, copy) NSString *downloadQuality;
@property (nonatomic) int32_t downloadStatus;
@property (nonatomic) int32_t fileOpenableState;
@property (nullable, nonatomic, copy) NSString *filePath;
@property (nullable, nonatomic, copy) NSString *format;
@property (nullable, nonatomic, copy) NSString *formatType;
@property (nullable, nonatomic, copy) NSString *guid;
@property (nonatomic) BOOL isInWishlist;
@property (nullable, nonatomic, retain) NSData *narrators;
@property (nonatomic) BOOL owned;
@property (nullable, nonatomic, copy) NSString *pfmID;
@property (nullable, nonatomic, copy) NSString *productID;
@property (nullable, nonatomic, copy) NSString *publisher;
@property (nullable, nonatomic, copy) NSDate *releaseDate;
@property (nonatomic) int64_t runningTime;
@property (nonatomic) BOOL sample;
@property (nullable, nonatomic, copy) NSString *sampleClipURL;
@property (nullable, nonatomic, retain) NSData *similarProducts;
@property (nullable, nonatomic, copy) NSString *title;
@property (nullable, nonatomic, retain) NSSet<Companion *> *companions;
@property (nullable, nonatomic, retain) NSSet<Image *> *images;

@end

@interface Audiobook (CoreDataGeneratedAccessors)

- (void)addCompanionsObject:(Companion *)value;
- (void)removeCompanionsObject:(Companion *)value;
- (void)addCompanions:(NSSet<Companion *> *)values;
- (void)removeCompanions:(NSSet<Companion *> *)values;

- (void)addImagesObject:(Image *)value;
- (void)removeImagesObject:(Image *)value;
- (void)addImages:(NSSet<Image *> *)values;
- (void)removeImages:(NSSet<Image *> *)values;

@end

NS_ASSUME_NONNULL_END
