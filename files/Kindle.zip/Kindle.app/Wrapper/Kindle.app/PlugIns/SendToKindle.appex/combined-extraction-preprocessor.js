
var getAbsoluteURL = function (url) {

    if (url !== null) {
        var location = window.location;
        if (url.match(/^\/\//i) !== null) {
            url = location.protocol + url;
        }
        else if (url.match(/^(http|https|mailto:|#.+)/i) === null) {
            // Set absolute path, if needed.
            if (url.substr(0, 1) !== "/") {
                var pathname = location.pathname.substring(0, location.pathname.lastIndexOf("/")) + "/";
                url = pathname + url;
            }
            
            url = (location.origin || (location.protocol + "//" + location.host)) + url;
        }
    } 
    return url;
}

var getURLFromRegexMatch = function (regexMatch) {
    var matchComponents = regexMatch.split("\"");
    var url = matchComponents[1];
    var absoluteUrl = getAbsoluteURL(url);
    return absoluteUrl;
}

var MyExtensionJavaScriptClass = function() {};

var completionFunction;
MyExtensionJavaScriptClass.prototype = {
    run: function(arguments) {
                                      
        var extractionSupportedExtensions = new Array("html", "htm", "shtml", "jhtml", "asp", "aspx", "axd", "asx", "asmx", "ashx", "cfm", "pl", "jsp", "jspx", "cgi", "php", "php3", "php4", "phtml", "rb", "rhtml");
                                      
        var absoluteUrl = window.location["href"];
        var baseUrl = absoluteUrl.split("?")[0];
        var pathComponents = baseUrl.split("/");
        var filenameComponents = pathComponents[pathComponents.length - 1].split(".");
                                      
        var extension;
        if (filenameComponents.length > 1) {
            extension = filenameComponents[filenameComponents.length - 1].toLowerCase();
            extension = extension.split("#")[0];
            extension = extension.split(";")[0];
        } else {
            extension = "html";
        }
                          
        completionFunction = arguments.completionFunction;     
        if (extractionSupportedExtensions.indexOf(extension) >= 0) {
                      
            var title = document.title + ".html";
            completionFunction({"url": absoluteUrl, "title": title, "source": document.documentElement.outerHTML});
                       
        } else {
            arguments.completionFunction({"url": absoluteUrl});
        }
    }
};

// The JavaScript file must contain a global object named "ExtensionPreprocessingJS".
var ExtensionPreprocessingJS = new MyExtensionJavaScriptClass;

